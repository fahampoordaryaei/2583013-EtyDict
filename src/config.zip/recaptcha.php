<?php

declare(strict_types=1);

const RECAPTCHA_SECRET_KEY = '6LdtfCEsAAAAAN_AUA9iFgLqiHrXB9aR96Wnmy9W';
const RECAPTCHA_SCORE_THRESHOLD = 0.5;

function verifyRecaptcha(string $response): bool
{
    $verifyUrl = 'https://www.google.com/recaptcha/api/siteverify';
    $data = [
        'secret' => RECAPTCHA_SECRET_KEY,
        'response' => $response
    ];

    $options = [
        'http' => [
            'header' => "Content-Type: application/x-www-form-urlencoded",
            'method' => 'POST',
            'content' => http_build_query($data)
        ]   
    ];

    $context = stream_context_create($options);
    $result = file_get_contents($verifyUrl, false, $context);

    if ($result === false) {
        return false;
    }

    $responseData = json_decode($result, true);
    if (!$responseData || $responseData['success'] !== true) {
        return false;
    }

    return ($responseData['score'] ?? 0) >= RECAPTCHA_SCORE_THRESHOLD;
}
