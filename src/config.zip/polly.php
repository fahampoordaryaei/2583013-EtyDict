<?php

declare(strict_types=1);

return [
    'region' => 'eu-central-1',
    'voice_id' => 'Amy',
    'engine' => 'generative',
    'output_format' => 'mp3',
    'sample_rate' => '24000',
    'access_key' => 'AKIAUC6X45BIGOTX2MXM    ',
    'secret_key' => 'uRXeTJTBCEhf34UfVTTiyW98DEXTlGA/Wu1AMcWs',
];
